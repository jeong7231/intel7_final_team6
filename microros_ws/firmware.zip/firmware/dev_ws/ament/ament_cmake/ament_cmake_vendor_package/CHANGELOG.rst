^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ament_vendor_package
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.3.12 (2025-06-27)
-------------------

1.3.11 (2024-11-25)
-------------------
* Add explicit git dependency from ament_cmake_vendor_package (`#557 <https://github.com/ament/ament_cmake/issues/557>`_)
* Fix patch file dependencies in ament_cmake_vendor_package (`#520 <https://github.com/ament/ament_cmake/issues/520>`_) (`#548 <https://github.com/ament/ament_cmake/issues/548>`_)
* Contributors: mergify[bot], roscan-tech

1.3.10 (2024-07-26)
-------------------

1.3.9 (2024-05-15)
------------------

1.3.8 (2024-02-16)
------------------

1.3.7 (2024-01-24)
------------------

1.3.6 (2023-11-13)
------------------

1.3.5 (2023-06-22)
------------------
* Add ament_cmake_vendor_package package (`#467 <https://github.com/ament/ament_cmake/issues/467>`_)
