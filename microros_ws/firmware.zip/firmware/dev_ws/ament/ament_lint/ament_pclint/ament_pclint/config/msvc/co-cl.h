#ifndef GS_PCLP_CO_CL_H
#define GS_PCLP_CO_CL_H
#define _INTEGRAL_MAX_BITS 64
#define _WIN32 1
#define _WIN64 1
#define _M_X64 1
#define _M_AMD64 100
#define _MSC_FULL_VER 190000000
#define _MSC_VER 1900
#define _WINSOCK_DEPRECATED_NO_WARNINGS 1
#define _MSC_EXTENSIONS 1
#define _NATIVE_WCHAR_T_DEFINED 1
#define _WCHAR_T_DEFINED 1
#define __FUNCTION__ "func"
#define __FUNCDNAME__ "funcname"
#define __FUNCSIG__ "funcsig"
#define L__FUNCTION__ L"func"
#ifndef __cplusplus
void __assert(_Bool);  /*lint !e793 !e955 !e970 !e1904 !e9141 */
#endif
#ifdef __cplusplus
void __assert(bool);  /*lint !e793 !e955 !e970 !e1904 !e9141 */
#endif

#endif /* GS_PCLP_CO_CL_H */
